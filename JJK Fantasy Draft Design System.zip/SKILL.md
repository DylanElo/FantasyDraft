---
name: jjk-fantasy-draft-design
description: Use this skill to generate well-branded interfaces and assets for JJK Fantasy Draft, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping a dark, cursed-energy-themed Jujutsu Kaisen draft game.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation for this brand

- **Product:** JJK Fantasy Draft — a Jujutsu Kaisen–themed card‑drafting game. Players take turns drawing random JJK character cards to build a 5‑character team; highest combined energy score wins. Mobile‑first web UI with a parallel Telegram bot.
- **Voice:** Confident, terse, slightly theatrical. Mixes anime‑lore vocabulary (cursed energy, sorcerer, domain) with arcade directness (Draw, Keep, Pass).
- **Logomark:** the kanji **呪** ("curse") — first character of 呪術. Always purple on dark, often on a rounded tile with a soft purple glow.
- **Colors:** base `#07071a` near‑black blue, primary `#7c3aed` purple, victory `#f59e0b` gold. See `colors_and_type.css` for the full token set.
- **Type:** Cinzel (display, character names, winners) + Inter (everything else). Both Google Fonts.
- **Vibe:** midnight shrine, talismans, glowing cursed energy. Drop shadows are colored auras, not depth shadows.

## Two design layers

1. **Baseline** — what the product looks like today (`colors_and_type.css`, the preview cards, the lower‑level UI kit pieces). Use this for mocks that need to look like the current shipped UI.
2. **AAA "Domain Expansion"** (`AAA-DIRECTION.md`) — an elevated direction with 3D tilt cards, holographic foils, screen shake, ink‑brush winner reveals, 領域展開 cinematic curtains, and synthesised SFX. Use this when the user asks for something cinematic / premium / "Hearthstone‑feel". The UI kit at `ui_kits/web-app/` ships both — AAA Mode is toggle‑able.

## Heuristic eval is included

`heuristic-eval.md` documents UX gaps in the source product (missing search in browse, silent deck‑empty fallback, no undo, etc.). When designing new screens, lift fixes from this file unless the user says otherwise.

## What's in this folder

```
README.md             — primary brand doc (content + visual foundations)
AAA-DIRECTION.md      — Triple‑A elevation playbook
heuristic-eval.md     — UX audit + gap analysis
colors_and_type.css   — all design tokens (color, type, spacing, radius, shadow, motion)
fonts/README.md       — font notes (Cinzel + Inter via Google Fonts)
assets/               — logo lockups, energy orbs, Lucide‑family icons
preview/              — atomic design‑system cards
ui_kits/web-app/      — high‑fidelity React recreation of the web UI (with AAA upgrades)
docs/, web/, jjk_bot/ — imported source code for reference
```

## Working rules

- **Never invent new character art.** Pull `image_url` fields from `docs/characters.json` or `ui_kits/web-app/characters.sample.json`. Real anime keyart from the Fandom wiki only.
- **Never invent new kanji.** The only sanctioned kanji in this brand are: 呪 (logo / watermark), 領域展開 (Domain Expansion moment), and 一二三四 (player counters in the Lobby).
- **Never substitute a different sans for Inter** or a different inscribed serif for Cinzel. If you need a third family for ceremonial moments, Cinzel Decorative is on the approved list (used for the winner name).
- **Icons are Lucide family** at 2–2.5px stroke, round caps/joins, currentColor. The six in `assets/icons/` are extracted from the source product; pull additional icons from `lucide.dev` at the same settings.
- **Faction colors are load‑bearing** — every character has exactly one faction, and the card's identity comes from its 50%‑opacity colored border. Don't reuse faction colors for chrome.
- **Color‑left‑border on cards is allowed _only_ on skill rows** (where it denotes the skill type: green = physical, red = bloodline, blue = energy, purple = strategic, gold = ULT). Don't generalize this pattern to other cards.
- **Gold appears only on the Results screen, the active player's name, and rare reward moments.** Never on chrome.
- **Speak in second‑person imperative** on action surfaces ("Build your cursed team", "Tap to draw"). Third‑person announcements in toasts ("Yuji kept Black Flash.").

## Common asks → starter file

| Ask | Start from |
|---|---|
| "Mock a new screen for this app" | `ui_kits/web-app/index.html` (copy + edit) |
| "Make a marketing/announcement slide" | A blank `<deck-stage>` slide using `colors_and_type.css` tokens + `assets/logo-lockup.svg` |
| "Recreate just one component" | The matching file in `preview/` (open + copy the styles) |
| "Premium / cinematic version" | `AAA-DIRECTION.md` + `ui_kits/web-app/effects.js` |

When in doubt, read `README.md`'s VISUAL FOUNDATIONS section end‑to‑end before designing — it answers borders, shadows, transparency, animation, cards, imagery, layout rules, and corner radii.
